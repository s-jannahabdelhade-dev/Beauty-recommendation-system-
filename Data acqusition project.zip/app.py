import streamlit as st
import pandas as pd
import networkx as nx
import matplotlib.pyplot as plt
import seaborn as sns
from serpapi import GoogleSearch
import json
import os

st.set_page_config(page_title="Barbie Beauty", layout="wide")
st.markdown("""
    <style>
    .stApp { background-color: #FCE4EC; }
    h1, h2, h3 { color: #D81B60 !important; text-align: center; }
    .category-card {
        background-color: white;
        padding: 30px;
        border-radius: 20px;
        box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        text-align: center;
        border: 2px solid #F06292;
        transition: transform 0.3s;
        margin-bottom: 20px;
    }
    .category-card:hover {
        transform: scale(1.05);
        border-color: #D81B60;
    }
    .card-icon { font-size: 60px; margin-bottom: 10px; }
    .card-title { font-size: 24px; font-weight: bold; color: #D81B60; }
    div.stButton > button {
        width: 100%;
        background-color: #F06292;
        color: white;
        border-radius: 10px;
        border: none;
        height: 50px;
        font-weight: bold;
    }
    div.stButton > button:hover { background-color: #D81B60; color: white; }
    </style>
""", unsafe_allow_html=True)

def load_users():
    if os.path.exists("users.json"):
        with open("users.json", "r") as f:
            return json.load(f)
    return {}

def save_users(users):
    with open("users.json", "w") as f:
        json.dump(users, f)

def pr(item):
    price = str(item.get("price","0"))
    clean_price = price.replace("$", "").replace(",", "").strip()
    try:
        return float(clean_price)
    except:
        return 0.0

if 'logged_in' not in st.session_state:
    st.session_state['logged_in'] = False
if 'choice' not in st.session_state:
    st.session_state['choice'] = None

if not st.session_state['logged_in']:
    st.title("Barbie World ")
    tab1, tab2 = st.tabs(["Login", "Sign Up"])
    with tab1:
        u = st.text_input("Username", key="l_u")
        p = st.text_input("Password", type="password", key="l_p")
        if st.button("Login"):
            users = load_users()
            if u in users and users[u] == p:
                st.session_state['logged_in'] = True
                st.session_state['username'] = u
                st.rerun()
            else:
                st.error("Error!")
    with tab2:
        nu = st.text_input("New User", key="r_u")
        np = st.text_input("New Pass", type="password", key="r_p")
        if st.button("Sign Up"):
            users = load_users()
            if nu and np:
                users[nu] = np
                save_users(users)
                st.success("Done!")
else:
    st.title(f"Welcome Barbie {st.session_state['username']} ")

    if st.sidebar.button("Logout"):
        st.session_state['logged_in'] = False
        st.session_state['choice'] = None
        st.rerun()
    if st.session_state['choice'] is not None:
        if st.sidebar.button("Back to Menu"):
            st.session_state['choice'] = None
            st.rerun()
    if st.session_state['choice'] is None:
        col1, col2 = st.columns(2)
        with col1:
            st.markdown('<div class="category-card"><div class="card-icon">💄💅🏻</div><div class="card-title">Makeup</div></div>', unsafe_allow_html=True)
            if st.button("Explore Makeup"):
                st.session_state['choice'] = "Makeup"
                st.rerun()
        with col2:
            st.markdown('<div class="category-card"><div class="card-icon">🧴🧖🏻‍♀️🫧</div><div class="card-title">Skincare</div></div>', unsafe_allow_html=True)
            if st.button("Explore Skincare"):
                st.session_state['choice'] = "Skincare"
                st.rerun()
    elif st.session_state['choice'] == "Makeup":
        st.subheader("Makeup Analyzer")
        
        skin_tones_colors = {
            "Light": "Perfect colors for you: Soft Pink, Peach, Coral, and Light Berry.",
            "Medium": "Perfect colors for you: Rose, Mauve, Warm Red, and Caramel.",
            "Dark": "Perfect colors for you: Deep Plum, Rich Burgundy, Bronze, and Copper."
        }
        selected_tone = st.selectbox("Select your skin tone first:", list(skin_tones_colors.keys()))
        st.success(skin_tones_colors[selected_tone])

        inp = st.text_input("Products (e.g. Lipgloss, Blush):", "Lipgloss")
        if st.button("Search"):
            items = [i.strip() for i in inp.split(",")]
            res_list, table_data = [], []
            G = nx.Graph()
            G.add_node("Makeup", color="gray")
            with st.spinner('Loading'):
                for i in items:
                    G.add_node(i, color="gray")
                    G.add_edge("Makeup", i)
                    query = {"engine": "google_shopping", "q": i, "api_key": "605e14e359ed3c99686acc31bee7e556aa126e2163bbc14117fed9a5c54fef4a"}
                    search_res = GoogleSearch(query).get_dict().get("shopping_results", [])
                    for r in search_res:
                        r["i"] = i
                        res_list.append(r)
            if res_list:
                res_list.sort(key=pr)
                
                for item in res_list[:15]:
                    name = item.get("title")
                    G.add_node(name[:15], color="pink")
                    G.add_edge(item["i"], name[:15])
                    l_url = item.get("link") or item.get("product_link") or ""
                    table_data.append({"Product": name, "Category": item["i"], "Store": item.get("source"), "Price": pr(item), "Rating": float(item.get("rating", 0)), "Link": l_url})
                
                df = pd.DataFrame(table_data)
                st.dataframe(df, column_config={"Link": st.column_config.LinkColumn()})
                
                c1, c2 = st.columns(2)
                with c1:
                    fig, ax = plt.subplots()
                    nx.draw(G, with_labels=True, node_color=[data.get('color','pink') for n,data in G.nodes(data=True)], node_size=1000, font_size=7)
                    st.pyplot(fig)
                with c2:
                    fig3 = plt.figure()
                    ax3 = fig3.add_subplot(projection='3d')
                    ax3.scatter(df['Price'], df['Rating'], range(len(df)), c='hotpink')
                    ax3.set_xlabel('Price')
                    ax3.set_ylabel('Rating')
                    ax3.set_zlabel('Product Index')
                    ax3.set_title('Price vs Rating Clustering')
                    st.pyplot(fig3)

                st.markdown("---")
                st.subheader("Data Insights")
                heat = df.pivot_table(index='Category', columns='Store', values='Price', aggfunc='mean')
                h1, h2 = st.columns(2)
                with h1:
                    f_h, ax_h = plt.subplots()
                    sns.heatmap(heat, annot=True, cmap="PuRd")
                    st.pyplot(f_h)
                with h2:
                    f_b, ax_b = plt.subplots()
                    sns.boxplot(x='Category', y='Price', data=df, palette="PuRd")
                    st.pyplot(f_b)

    elif st.session_state['choice'] == "Skincare":
        st.subheader("Skincare Analyzer")
        try:
            sdf = pd.read_csv("clean_skincare_data.csv")
            probs = {
                "acne": ["Salicylic Acid", "Niacinamide"], 
                "dryness": ["Hyaluronic Acid", "Ceramides"], 
                "aging": ["Retinol", "Vitamin C"], 
                "redness": ["Aloe Vera", "Green Tea"]
            }
            problem = st.selectbox("Concern:", list(probs.keys()))
            if st.button("Analyze"):
                reco = sdf[sdf["ingredients"].str.contains("|".join(probs[problem]), case=False, na=False)].iloc[:3]
                s_res, s_table = [], []
                G_s = nx.Graph()
                G_s.add_node(problem, color="gray")
                with st.spinner('Loading...'):
                    for p_n in reco["name"].tolist():
                        q = {"engine": "google_shopping", "q": p_n, "api_key": "605e14e359ed3c99686acc31bee7e556aa126e2163bbc14117fed9a5c54fef4a"}
                        res = GoogleSearch(q).get_dict().get("shopping_results", [])
                if res: s_res.extend(res[:15])
                s_res.sort(key=pr)
                for item in s_res:
                    n = item.get("title")
                    G_s.add_node(n[:15], color="pink")
                    G_s.add_edge(problem, n[:15])
                    sl_url = item.get("link") or item.get("product_link") or ""
                    s_table.append({"Product": n, "Category": problem, "Store": item.get("source"), "Price": pr(item), "Rating": float(item.get("rating", 3)), "Link": sl_url})
                
                df_s = pd.DataFrame(s_table)
                st.dataframe(df_s, column_config={"Link": st.column_config.LinkColumn()})
                
                sc1, sc2 = st.columns(2)
                with sc1:
                    fig_s, ax_s = plt.subplots()
                    nx.draw(G_s, with_labels=True, node_color=[data.get('color','pink') for n,data in G_s.nodes(data=True)], node_size=1000, font_size=7)
                    st.pyplot(fig_s)
                with sc2:
                    fig3s = plt.figure()
                    ax3s = fig3s.add_subplot(projection='3d')
                    ax3s.scatter(df_s['Price'], df_s['Rating'], range(len(df_s)), c='hotpink')
                    ax3s.set_xlabel('Price')
                    ax3s.set_ylabel('Rating')
                    ax3s.set_zlabel('Product Index')
                    ax3s.set_title('Price vs Rating Clustering')
                    st.pyplot(fig3s)

                st.markdown("---")
                st.subheader("Data Insights")
                heat_s = df_s.pivot_table(index='Category', columns='Store', values='Price', aggfunc='mean')
                sh1, sh2 = st.columns(2)
                with sh1:
                    f_hs, ax_hs = plt.subplots()
                    sns.heatmap(heat_s, annot=True, cmap="PuRd")
                    st.pyplot(f_hs)
                with sh2:
                    f_bs, ax_bs = plt.subplots()
                    sns.boxplot(x='Category', y='Price', data=df_s, palette="PuRd")
                    st.pyplot(f_bs)
        except:
            st.error("Check CSV file.")